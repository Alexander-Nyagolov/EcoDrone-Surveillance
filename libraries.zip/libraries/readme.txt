За информация относно инсталирането на библиотеки, вижте: http://www.arduino.cc/en/Guide/Libraries
